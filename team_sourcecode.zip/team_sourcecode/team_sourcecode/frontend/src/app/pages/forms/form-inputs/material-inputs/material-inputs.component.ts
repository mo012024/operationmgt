import { Component } from '@angular/core';

@Component({
  selector: 'ngx-material-inputs',
  templateUrl: './material-inputs.component.html',
  styleUrls: ['./material-inputs.component.scss'],
})
export class MaterialInputsComponent {}
