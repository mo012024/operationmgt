import { Component } from '@angular/core';

@Component({
  selector: 'ngx-material-buttons',
  templateUrl: './material-buttons.component.html',
  styleUrls: ['./material-buttons.component.scss'],
})
export class MaterialButtonsComponent {}
